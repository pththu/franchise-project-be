create view pg_stat_statements_info(dealloc, stats_reset) as
SELECT dealloc,
       stats_reset
FROM pg_stat_statements_info() pg_stat_statements_info(dealloc, stats_reset);

alter table pg_stat_statements_info
    owner to postgres;

grant select on pg_stat_statements_info to public;

grant delete, insert, references, select, trigger, truncate, update on pg_stat_statements_info to sa;

